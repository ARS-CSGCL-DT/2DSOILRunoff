How to run each example:
Ex1: use preprocessor definition EX_1 when compilint
     Note: This simulation was made for 1/10 length of the real soil slope.
           The result is reported as "cm^2/15 sec". One should multiply the results by 5.1 cm (width of the soil slope), 
           10 (length scaling number) and 1/15 (time scaling number), then compare to the experimental results.
Ex2: remove all preprocessor definitions;
Ex3: Use preprocessor definition EX_3;
Ex4: soil mulching: remove preprocessor definitions;
     Plastic mulching: use preprocessor defintion EX_4P;