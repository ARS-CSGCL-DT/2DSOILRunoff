clear all;
close all;
clc;

lx=30;
angle=50;

x=0:2:30;
y=15*cos((pi./2./(lx)).*x);

plot(x,y)


